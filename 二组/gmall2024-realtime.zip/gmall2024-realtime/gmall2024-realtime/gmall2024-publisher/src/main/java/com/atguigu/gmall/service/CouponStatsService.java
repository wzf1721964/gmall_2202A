package com.atguigu.gmall.service;

import com.atguigu.gmall.bean.CouponReduceStats;

import java.util.List;

public interface CouponStatsService {
    List<CouponReduceStats> getCouponStats(Integer date);
}